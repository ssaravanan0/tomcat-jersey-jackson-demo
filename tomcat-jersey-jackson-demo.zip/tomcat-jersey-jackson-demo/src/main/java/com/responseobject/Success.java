package com.responseobject;
public class Success {

	String success;

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}
	
	

 // Getter Methods 



 // Setter Methods 


}