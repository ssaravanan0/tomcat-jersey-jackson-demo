package com.responseobject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Failure {
	/* ArrayList < Object > fault = new ArrayList < Object > (); */
	
	  
	 
	 private Map<String, Object> fault;

	public Map<String, Object> getFault() {
		return fault;
	}

	public void setFault(Map<String, Object> fault) {
		this.fault = fault;
	}

}