package com.requestobject;
public class RequestEntity {
 UpdateCustomersPrimaryUserEmailAddressRequest UpdateCustomersPrimaryUserEmailAddressRequestObject;


 // Getter Methods 

 public UpdateCustomersPrimaryUserEmailAddressRequest getUpdateCustomersPrimaryUserEmailAddressRequest() {
  return UpdateCustomersPrimaryUserEmailAddressRequestObject;
 }

 // Setter Methods 

 public void setUpdateCustomersPrimaryUserEmailAddressRequest(UpdateCustomersPrimaryUserEmailAddressRequest UpdateCustomersPrimaryUserEmailAddressRequestObject) {
  this.UpdateCustomersPrimaryUserEmailAddressRequestObject = UpdateCustomersPrimaryUserEmailAddressRequestObject;
 }
}
