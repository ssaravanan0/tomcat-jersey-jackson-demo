package com.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY)
//@XmlRootElement       //only needed if we also want to generate XML
public class UpdateCustomerPrimaryUserEmailAddress {
    
    private String success;
    private String faliure;
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getFaliure() {
		return faliure;
	}
	public void setFaliure(String faliure) {
		this.faliure = faliure;
	}
    
    
    
       
}