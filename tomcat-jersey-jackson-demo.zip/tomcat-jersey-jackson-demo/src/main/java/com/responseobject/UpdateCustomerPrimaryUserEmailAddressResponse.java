package com.responseobject;

public class UpdateCustomerPrimaryUserEmailAddressResponse {
	Failure FailureObject;
	Success SuccessObject;

	// Getter Methods

	public Failure getFailure() {
		return FailureObject;
	}

	// Setter Methods

	public void setFailure(Failure failureObject) {
		this.FailureObject = failureObject;
	}

//Getter Methods 

	public Success getSuccess() {
		return SuccessObject;
	}

// Setter Methods 

	public void setSuccess(Success successObject) {
		this.SuccessObject = successObject;
	}
}
