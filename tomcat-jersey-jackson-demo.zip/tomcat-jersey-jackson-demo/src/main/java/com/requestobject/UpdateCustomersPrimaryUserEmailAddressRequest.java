package com.requestobject;
public class UpdateCustomersPrimaryUserEmailAddressRequest {
 AccountIdentification AccountIdentificationObject;
 private String desiredPrimaryContactEmailAddress;


 // Getter Methods 

 public AccountIdentification getAccountIdentification() {
  return AccountIdentificationObject;
 }

 public String getDesiredPrimaryContactEmailAddress() {
  return desiredPrimaryContactEmailAddress;
 }

 // Setter Methods 

 public void setAccountIdentification(AccountIdentification accountIdentificationObject) {
  this.AccountIdentificationObject = accountIdentificationObject;
 }

 public void setDesiredPrimaryContactEmailAddress(String desiredPrimaryContactEmailAddress) {
  this.desiredPrimaryContactEmailAddress = desiredPrimaryContactEmailAddress;
 }
}
