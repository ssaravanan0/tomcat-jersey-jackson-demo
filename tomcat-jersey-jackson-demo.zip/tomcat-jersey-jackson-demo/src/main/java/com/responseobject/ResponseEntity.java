package com.responseobject;
public class ResponseEntity {
 UpdateCustomerPrimaryUserEmailAddressResponse UpdateCustomerPrimaryUserEmailAddressResponseObject;


 // Getter Methods 

 public UpdateCustomerPrimaryUserEmailAddressResponse getUpdateCustomerPrimaryUserEmailAddressResponse() {
  return UpdateCustomerPrimaryUserEmailAddressResponseObject;
 }

 // Setter Methods 

 public void setUpdateCustomerPrimaryUserEmailAddressResponse(UpdateCustomerPrimaryUserEmailAddressResponse UpdateCustomerPrimaryUserEmailAddressResponseObject) {
  this.UpdateCustomerPrimaryUserEmailAddressResponseObject = UpdateCustomerPrimaryUserEmailAddressResponseObject;
 }
}
