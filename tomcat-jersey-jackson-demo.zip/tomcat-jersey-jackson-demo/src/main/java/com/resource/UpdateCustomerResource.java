package com.resource;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.UpdateCustomerPrimaryUserEmailAddress;
import com.requestobject.AccountIdentification;
import com.requestobject.RequestEntity;
import com.requestobject.UpdateCustomersPrimaryUserEmailAddressRequest;
import com.responseobject.ResponseEntity;
import com.responseobject.Failure;
import com.responseobject.Success;
import com.responseobject.UpdateCustomerPrimaryUserEmailAddressResponse;



@Path("/UpdateCustomerPrimaryUserEmailAddress")
public class UpdateCustomerResource {
      
    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON}) 
    @Path("/posterror")
    public ResponseEntity postPerson(RequestEntity pers) throws Exception{
    	
    	System.out.println("UpdateCustomersPrimaryUserEmailAddressRequest >>>>>>>>>>>>>>>>> ");
    	
    	UpdateCustomersPrimaryUserEmailAddressRequest req = pers.getUpdateCustomersPrimaryUserEmailAddressRequest();
    	AccountIdentification accountIdentificationObject = req.getAccountIdentification();
    	accountIdentificationObject.getAccountNumber();
    	accountIdentificationObject.getSiteReference();
    	req.getDesiredPrimaryContactEmailAddress();
    	
       System.out.println("Account number >>>>>>>>>>>>>>>>> "+accountIdentificationObject.getAccountNumber());
       System.out.println("SiteReference >>>>>>>>>>>>>>>>> "+accountIdentificationObject.getSiteReference());
       System.out.println("PrimaryContactEmailAddress >>>>>>>>>>>>>>>>> "+req.getDesiredPrimaryContactEmailAddress());
       
       UpdateCustomerPrimaryUserEmailAddress res = new UpdateCustomerPrimaryUserEmailAddress();
       res.setSuccess("0");
       
       UpdateCustomerPrimaryUserEmailAddressResponse res1 = new UpdateCustomerPrimaryUserEmailAddressResponse();
       
       
       //ArrayList < Object > fault = new ArrayList < Object > ();
       Failure failureObject = new Failure();
       Map<String, Object> fault = new HashMap<String, Object>();
       fault.put("code", "LC0000001");
       fault.put("severity", "CRITICAL");
       fault.put("technicalDescription", "System Exception");
       fault.put("sourceSystem", "Middleware");
       failureObject.setFault(fault);
       res1.setFailure(failureObject);
       //failureObject.setFailure(fault);
     
       ResponseEntity reso = new ResponseEntity();
       reso.setUpdateCustomerPrimaryUserEmailAddressResponse(res1);
       return reso;
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON}) 
    @Path("/post")
    public ResponseEntity postPerson1(RequestEntity pers) throws Exception{
    	
    	System.out.println("UpdateCustomersPrimaryUserEmailAddressRequest >>>>>>>>>>>>>>>>> ");
    	
    	UpdateCustomersPrimaryUserEmailAddressRequest req = pers.getUpdateCustomersPrimaryUserEmailAddressRequest();
    	AccountIdentification accountIdentificationObject = req.getAccountIdentification();
    	accountIdentificationObject.getAccountNumber();
    	accountIdentificationObject.getSiteReference();
    	req.getDesiredPrimaryContactEmailAddress();
    	
       System.out.println("Account number >>>>>>>>>>>>>>>>> "+accountIdentificationObject.getAccountNumber());
       System.out.println("SiteReference >>>>>>>>>>>>>>>>> "+accountIdentificationObject.getSiteReference());
       System.out.println("PrimaryContactEmailAddress >>>>>>>>>>>>>>>>> "+req.getDesiredPrimaryContactEmailAddress());
       
       UpdateCustomerPrimaryUserEmailAddress res = new UpdateCustomerPrimaryUserEmailAddress();
       res.setSuccess("0");
       
       UpdateCustomerPrimaryUserEmailAddressResponse res1 = new UpdateCustomerPrimaryUserEmailAddressResponse();
       
       Success success = new Success(); 
       success.setSuccess("0");
       res1.setSuccess(success);
     
       ResponseEntity reso = new ResponseEntity();
       reso.setUpdateCustomerPrimaryUserEmailAddressResponse(res1);
       return reso;
    }
    
    @GET
    @Produces({MediaType.APPLICATION_JSON})  //add MediaType.APPLICATION_XML if you want XML as well (don't forget @XmlRootElement)
    public RequestEntity getAllMessages() throws Exception{
        
    	 System.out.println("Get CustomersPrimaryUserEmailAddressRequest >>>>>>>>>>>>>>>>> ");
    	 
    	UpdateCustomersPrimaryUserEmailAddressRequest req = new UpdateCustomersPrimaryUserEmailAddressRequest();
    	
    	AccountIdentification accountIdentificationObject = new AccountIdentification();
    	accountIdentificationObject.setAccountNumber("123") ;
    	accountIdentificationObject.setSiteReference(12);
    	req.setDesiredPrimaryContactEmailAddress("saran@tcs.com");
    	req.setAccountIdentification(accountIdentificationObject);
    	
    	RequestEntity codebeautify = new RequestEntity();
    	
    	codebeautify.setUpdateCustomersPrimaryUserEmailAddressRequest(req);
    	
    	return codebeautify;
    }

}
