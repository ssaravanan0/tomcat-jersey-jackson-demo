package com.requestobject;
public class AccountIdentification {
 private String accountNumber;
 private float siteReference;


 // Getter Methods 

 public String getAccountNumber() {
  return accountNumber;
 }

 public float getSiteReference() {
  return siteReference;
 }

 // Setter Methods 

 public void setAccountNumber(String accountNumber) {
  this.accountNumber = accountNumber;
 }

 public void setSiteReference(float siteReference) {
  this.siteReference = siteReference;
 }
}